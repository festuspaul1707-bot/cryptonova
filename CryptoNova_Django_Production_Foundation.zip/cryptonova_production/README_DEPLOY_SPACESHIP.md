# CryptoNova production foundation — Spaceship deployment

This is a real Django application foundation, not a static HTML mockup. It includes user registration/login, a player dashboard, admin-managed player/KYC records, wallet-account records, a transaction ledger, provider/game catalog administration, and a responsive black-and-gold frontend.

## Important launch boundary
This code does **not** create blockchain deposit addresses, custody private keys, process real deposits/withdrawals, accept bets, or launch games. Those require contracted and approved providers, jurisdiction-specific legal review, security testing, and integration credentials. Wallet transaction controls are intentionally absent. The game lobby only displays games marked active + licensed and attached to an approved active provider. Do not change these safeguards just to make the site appear live.

## Before uploading
1. In Spaceship, confirm the hosting plan supports Python 3.12+, Django/WSGI or ASGI apps, persistent processes, environment variables, and PostgreSQL/MySQL. A File Manager alone does not prove Python app hosting is enabled.
2. If the account only offers static/PHP hosting or a cPanel backup restore screen, this Django app cannot run there as-is. Ask Spaceship support: "Does my hosting plan support deploying a Django 5.2 app with Python 3.12, Gunicorn, environment variables and PostgreSQL? Where is Setup Python App / Application Manager?"
3. Create a database and a dedicated database user. Prefer PostgreSQL. Keep credentials private.

## Typical cPanel Python app deployment (only if Spaceship enables it)
1. cPanel > Setup Python App (or Python App / Application Manager) > Create Application.
2. Select Python 3.12, set application root to `cryptonova`, application URL to your domain, and startup file/entry point as required by the host.
3. Upload/extract this ZIP into the application root using File Manager. Do not upload it as a cPanel full-account backup.
4. Configure the virtual environment and install `requirements.txt`.
5. Add environment variables from `.env.example` in the app manager. Generate a unique secret key; set `DJANGO_DEBUG=False`, `DJANGO_ALLOWED_HOSTS=crytonova.world,www.crytonova.world`, correct `DATABASE_URL`, and `CSRF_TRUSTED_ORIGINS=https://crytonova.world,https://www.crytonova.world`.
6. Set WSGI entry point to `config.wsgi:application` (or create the host-required `passenger_wsgi.py` adapter if cPanel specifically requires it; follow the host's instructions).
7. Run:
   `python manage.py migrate`
   `python manage.py createsuperuser`
   `python manage.py collectstatic --noinput`
8. Restart the application from the Python app manager.
9. Enable SSL for both `crytonova.world` and `www.crytonova.world`, then test registration, login, logout, password-reset email, admin, and mobile layout.

## Local smoke test
- Python 3.12+
- `python -m venv .venv`
- activate the environment
- `pip install -r requirements.txt`
- `python manage.py migrate`
- `python manage.py createsuperuser`
- `python manage.py runserver`

## Admin
Visit `/admin/` and sign in with the superuser. Create approved providers and licensed games only after verifying contracts and permitted territories. KYC status is an operational field, not a KYC verification service.

## Required before real-money launch
- Confirm the legal operating entity, headquarters, permitted countries, and licences for each product (gaming, betting, crypto custody/exchange/payment).
- Complete independent security review, threat model, penetration test, secrets management and backup/restore test.
- Integrate a contracted KYC/AML provider and sanctions/PEP screening with documented retention and appeal processes.
- Integrate an approved custody/MPC provider; do not store private keys in this application or its database.
- Obtain payment rails/provider approvals for each supported asset and fiat corridor.
- Implement transaction monitoring, withdrawal risk controls, reconciliation, limits, incident response and immutable audit trails.
- Complete privacy notice, terms, responsible-gaming controls, age/geolocation controls and legal review.
- Obtain game aggregator/provider contracts and test each launch flow in the provider's sandbox before production enablement.

## Hosting limitation
I cannot sign in to your Spaceship account or change DNS/hosting settings from this chat. The ZIP is the application source; it is not already hosted. The exact next deployment steps depend on whether your Spaceship plan exposes a Python application manager.
