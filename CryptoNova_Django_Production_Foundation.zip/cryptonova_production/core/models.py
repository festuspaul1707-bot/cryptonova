from django.conf import settings
from django.db import models

class PlayerProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    display_name = models.CharField(max_length=40, blank=True)
    country = models.CharField(max_length=80, blank=True)
    kyc_status = models.CharField(max_length=20, default="not_started",
        choices=[("not_started","Not started"),("pending","Pending review"),("approved","Approved"),("rejected","Rejected")])
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.display_name or self.user.username

class WalletAccount(models.Model):
    ASSETS = [(x,x) for x in ["BTC","ETH","USDT","USDC","BNB","MXN"]]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="wallet_accounts")
    asset = models.CharField(max_length=8, choices=ASSETS)
    balance = models.DecimalField(max_digits=28, decimal_places=10, default=0)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["user","asset"], name="unique_user_asset_wallet")]
    def __str__(self):
        return f"{self.user.username} {self.asset}"

class LedgerEntry(models.Model):
    TYPES = [("deposit","Deposit"),("withdrawal","Withdrawal"),("adjustment","Admin adjustment"),("bet","Bet"),("win","Game win")]
    STATUSES = [("pending","Pending"),("approved","Approved"),("rejected","Rejected"),("posted","Posted")]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    asset = models.CharField(max_length=8, choices=WalletAccount.ASSETS)
    entry_type = models.CharField(max_length=16, choices=TYPES)
    amount = models.DecimalField(max_digits=28, decimal_places=10)
    status = models.CharField(max_length=12, choices=STATUSES, default="pending")
    reference = models.CharField(max_length=100, unique=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["-created_at"]
    def __str__(self):
        return f"{self.reference} / {self.user}"

class GameProvider(models.Model):
    name = models.CharField(max_length=100)
    integration_status = models.CharField(max_length=20, default="not_configured",
        choices=[("not_configured","Not configured"),("testing","Testing"),("approved","Approved")])
    launch_endpoint = models.URLField(blank=True)
    active = models.BooleanField(default=False)
    def __str__(self):
        return self.name

class Game(models.Model):
    CATEGORIES = [("arcade","Arcade"),("slots","Slots"),("table","Table"),("sports","Sports"),("other","Other")]
    title = models.CharField(max_length=120)
    category = models.CharField(max_length=20, choices=CATEGORIES, default="arcade")
    provider = models.ForeignKey(GameProvider, null=True, blank=True, on_delete=models.SET_NULL)
    description = models.CharField(max_length=240, blank=True)
    active = models.BooleanField(default=False)
    licensed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title
