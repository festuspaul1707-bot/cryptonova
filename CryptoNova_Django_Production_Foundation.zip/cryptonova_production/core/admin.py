from django.contrib import admin
from .models import PlayerProfile, WalletAccount, LedgerEntry, GameProvider, Game

@admin.register(PlayerProfile)
class PlayerProfileAdmin(admin.ModelAdmin):
    list_display = ("user","display_name","country","kyc_status","created_at")
    list_filter = ("kyc_status","country")
    search_fields = ("user__username","user__email","display_name")

@admin.register(WalletAccount)
class WalletAccountAdmin(admin.ModelAdmin):
    list_display = ("user","asset","balance","updated_at")
    search_fields = ("user__username",)
    readonly_fields = ("updated_at",)

@admin.register(LedgerEntry)
class LedgerEntryAdmin(admin.ModelAdmin):
    list_display = ("reference","user","entry_type","asset","amount","status","created_at")
    list_filter = ("entry_type","asset","status")
    search_fields = ("reference","user__username")
    readonly_fields = ("created_at",)

@admin.register(GameProvider)
class GameProviderAdmin(admin.ModelAdmin):
    list_display = ("name","integration_status","active")
    list_filter = ("integration_status","active")

@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ("title","category","provider","licensed","active")
    list_filter = ("category","licensed","active")
    search_fields = ("title",)
