from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from .models import Game, WalletAccount, LedgerEntry

def home(request):
    return render(request, "home.html")

def games(request):
    items = Game.objects.filter(active=True, licensed=True, provider__active=True,
        provider__integration_status="approved").select_related("provider")
    return render(request, "games.html", {"games": items})

@login_required
def dashboard(request):
    wallets = WalletAccount.objects.filter(user=request.user).order_by("asset")
    activity = LedgerEntry.objects.filter(user=request.user)[:10]
    return render(request, "dashboard.html", {"wallets": wallets, "activity": activity})

@login_required
def wallet(request):
    wallets = WalletAccount.objects.filter(user=request.user).order_by("asset")
    activity = LedgerEntry.objects.filter(user=request.user)[:25]
    return render(request, "wallet.html", {"wallets": wallets, "activity": activity})

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Your account has been created.")
            return redirect("dashboard")
    else:
        form = UserCreationForm()
    return render(request, "registration/register.html", {"form": form})
